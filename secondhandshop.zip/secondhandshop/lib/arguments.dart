
class ScreenArguments {
  int? index;
  final list;
  String? ccat;
  ScreenArguments({
    this.index,
    this.list,
    this.ccat
  });
}