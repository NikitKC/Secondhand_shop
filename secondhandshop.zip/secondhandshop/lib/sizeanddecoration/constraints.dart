import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF1E88E5);
const Color bgColor = Color(0xFFFBFBFD);

const double defaultPadding = 16.0;
const double defaultBorderRadius = 12.0;
 const Color darkgrey = Color(0xff747F8F);