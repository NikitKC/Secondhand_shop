package com.semproject.secondhandshop.secondhandshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
